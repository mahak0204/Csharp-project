﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.pwc.shapes1.shapes;

namespace com.pwc.shapes1.geometry
{
    public class Shapecs
    {
        public static void Main(string[] args)
        {
            Circle circle = new Circle();
            Console.WriteLine("Shapecs - Default Radius: " + circle.Radius());
        }
    }
}
