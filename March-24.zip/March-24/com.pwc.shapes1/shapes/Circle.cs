﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.pwc.shapes1.shapes
{
    public class Circle
    {
        private float radius;
        internal float pi;
 

    public Circle()
        {
            this.radius = 1.5f;
        }
        internal Circle(float radius) : this(radius, 3.5f)
        { }

        private Circle(float radius, float pi)
        {
            this.radius = radius;
            this.pi = pi;
        }

        public float Radius()
        {
            return this.radius;
        }
        public float CalculateCircleArea(float radius)
        {
            return pi * radius * radius;
        }

        public float CalculateCircumference(float radius)
        {
            return 2 * pi * radius;
        }

        public static void Main(string[] args)
        {
            Circle c = new Circle();

            float area = c.CalculateCircleArea(c.radius);
            float circumference = c.CalculateCircumference(c.radius);

            Console.WriteLine("Area: " + area);
            Console.WriteLine("Circumference: " + circumference);
        }
    }
}

