﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.pwc.shapes1.shapes
{
    public class Areacs
    {   
        public static void Main(string[] args)
        {
            Circle circle = new Circle(2.5f);
            Console.WriteLine("Areacs - Radius: 2.5");
        }

    }
}
