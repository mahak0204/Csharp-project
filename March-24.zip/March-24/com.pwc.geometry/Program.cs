﻿using com.pwc.shapes;
using System;

namespace com.pwc.geometry
{
    public class Shapecs
    {
        public static void Main(string[] args)
        {
            Circle circle = new Circle();
            Console.WriteLine("Shapecs - Radius initialized to: " + circle.Radius);

        }

    }
}
