﻿namespace Country
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CountrySet countrySet = new CountrySet();
            countrySet.StoreCountryName("India");
            countrySet.StoreCountryName("china");
            Console.WriteLine(countrySet.RetriveCountry("India"));
            Console.WriteLine(countrySet.RetriveCountry("USA"));
        }
    }
}
