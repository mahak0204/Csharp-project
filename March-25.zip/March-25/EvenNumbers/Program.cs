﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        EvenNumbers evenNumbers = new EvenNumbers();

        List<int> storedNumbers = evenNumbers.StoreEvenNumbers(10);

        List<int> doubledNumbers = evenNumbers.PrintEvenNumbers();

        int retrievedNumber = evenNumbers.RetrieveEvenNumber(4);
        Console.WriteLine(retrievedNumber);
    }
}