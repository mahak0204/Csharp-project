﻿using System;
using System.Collections.Generic;

class EvenNumbers
{
    private List<int> _A1;
    private List<int> _A2;

    public EvenNumbers()
    {
        _A1 = new List<int>();
        _A2 = new List<int>();
    }

    public List<int> StoreEvenNumbers(int N)
    {
        _A1.Clear();
        for (int i = 2; i <= N; i += 2)
        {
            _A1.Add(i);
        }
        return _A1;
    }

    public List<int> PrintEvenNumbers()
    {
        _A2.Clear();
        foreach (int num in _A1)
        {
            int doubled = num * 2;
            _A2.Add(doubled);
            Console.Write(doubled + " ");
        }
        Console.WriteLine();
        return _A2;
    }

    public int RetrieveEvenNumber(int N)
    {
        if (_A1.Contains(N))
            return N;
        return 0;
    }
}